<section class="cont_error">
    <div class="cx_error">
        <h1>Página Inexistente</h1>
        <a class="return_home" href="<?php echo INCLUDE_PATH; ?>">
			<button>
				Voltar à página principal?
			</button>
		</a>
    </div>
</section>