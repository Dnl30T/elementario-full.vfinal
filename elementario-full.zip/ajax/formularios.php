<?php
	include('../config.php');
	$data = array();
	$data['sucesso']= true;
	die(json_encode($data));
?>